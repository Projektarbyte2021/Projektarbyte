import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 21.06.2022
 * @author 
 */

public class Steuerung {
  
  // Anfang Attribute
  private Produktverwaltung produktverwaltung;
  private GUI gui;
  // Ende Attribute
  
  public Steuerung(GUI pGUI) {
    gui=pGUI;
    this.produktverwaltung = null;
  }

  // Anfang Methoden
  public Produktverwaltung getProduktverwaltung() {
    return produktverwaltung;
  }

  public GUI getGui() {
    return gui;
  }

  public void addProduct(int produktNr, String bezeichnung) {
    Produkt produkt = new Produkt();
    produktverwaltung.add(produkt);
  }

  // Ende Methoden
} // end of Steuerung
