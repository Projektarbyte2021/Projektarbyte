import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 21.06.2022
 * @author 
 */

public class Produktverwaltung {
  
  // Anfang Attribute
  private Produkt[] produkte = Produkt[1000];
  private int anzProdukte = 0;
  // Ende Attribute
  
  // Anfang Methoden
  public Produkt getProdukte(int nr) {
    return null;
  }

  public void add(Produkt produkt) {
    // TODO hier Quelltext einf�gen
    produkte[anzProdukte] = produkt;
    anzProdukte++;                            
    
  }

  public int getAnzProdukte() {
    return anzProdukte;
  }

  // Ende Methoden
} // end of Produktverwaltung
