/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 21.06.2022
 * @author 
 */

public class Produkt {
  
  // Anfang Attribute
  private int produktNr;
  private String bezeichnung;
  // Ende Attribute
  
  // Anfang Methoden
  public int getProduktNr() {
    return produktNr;
  }

  public String getBezeichnung() {
    return bezeichnung;
  }

  // Ende Methoden
} // end of Produkt
