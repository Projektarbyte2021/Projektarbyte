import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 21.06.2022
 * @author 
 */

public class GUI extends JFrame {
  // Anfang Attribute
  private JTextField jTextField1 = new JTextField();
  private JTextField jTextField2 = new JTextField();
  private JButton bSave = new JButton();
  private JLabel lPropduktNr = new JLabel();
  private JLabel lBezeichnung = new JLabel();
  
  private Steuerung steuerung;
  // Ende Attribute
  
  public GUI() { 
    // Frame-Initialisierung
    super();
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 456; 
    int frameHeight = 535;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setTitle("GUI");
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    // Anfang Komponenten
    
    jTextField1.setBounds(88, 64, 201, 49);
    cp.add(jTextField1);
    jTextField2.setBounds(96, 160, 193, 65);
    cp.add(jTextField2);
    bSave.setBounds(96, 296, 193, 73);
    bSave.setText("Save");
    bSave.setMargin(new Insets(2, 2, 2, 2));
    bSave.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bSave_ActionPerformed(evt);
      }
    });
    cp.add(bSave);
    lPropduktNr.setBounds(88, 32, 137, 33);
    lPropduktNr.setText("PropduktNr");
    cp.add(lPropduktNr);
    lBezeichnung.setBounds(96, 128, 153, 25);
    lBezeichnung.setText("Bezeichnung");
    cp.add(lBezeichnung);
    // Ende Komponenten
    
    steuerung = new Steuerung(this);
    setVisible(true);
    
  } // end of public GUI
  
  // Anfang Methoden
  
  public static void main(String[] args) {
    GUI gui = new GUI();
    //GUI gui2 = new GUI();
  } // end of main
  
  public void bSave_ActionPerformed(ActionEvent evt) {
    int b = Integer.valueOf(jTextField1.getText());
    steuerung.addProduct(b,jTextField2.getText());
    
  } // end of bSave_ActionPerformed

  // Ende Methoden
} // end of class GUI
